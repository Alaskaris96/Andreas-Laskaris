from django.urls import path,include
from . import views


urlpatterns = [
    path('', views.index),
    path('new1',views.new_inside)
]