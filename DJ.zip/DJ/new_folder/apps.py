from django.apps import AppConfig


class NewFolderConfig(AppConfig):
    name = 'new_folder'
