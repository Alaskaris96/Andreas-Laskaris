from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def index(request):
    return HttpResponse('We are inside the new folder!')


def new_inside(request):
    return HttpResponse('The view inside new_folder')